//connection string of our mongoDB
module.exports = {
  'secretKey': 'caoru-kunda-ijunc-hengh',
  'mongoUrl':'mongodb://localhost:27017/supermarket',
};