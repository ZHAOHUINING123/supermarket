let workdir = __dirname;
module.exports = {
  workdir: workdir
}