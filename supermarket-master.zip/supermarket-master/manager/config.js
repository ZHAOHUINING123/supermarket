//connection string of our mongoDB
module.exports = {
  'mongoUrl':'mongodb://localhost:27017/supermarket',
  'user':"igec",
  'password':"nhIyRXxoJ82gSF9wqH2aMYS5b3N3CTBp7YNgvuk49RQd09bcLGn2tHsXtulBfw0UclonKEA9s34HPHSg9sNfGQ=="
};